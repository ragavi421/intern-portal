fetch('http://localhost:5000/api/user')
  .then(res => res.json())
  .then(data => {
    document.getElementById('name').textContent = data.name;
    document.getElementById('code').textContent = data.referralCode;
    document.getElementById('amount').textContent = data.donationsRaised;
  })
  .catch(() => alert('Failed to load user data'));