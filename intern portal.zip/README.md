# Intern Portal (Round 1 Task)

A simple full-stack intern dashboard built using Node.js, Express, HTML, and CSS.

## 🔗 Live Links
- Frontend: [Netlify Link]
- Backend: [Render API Link]

## Features
- Dummy login page
- Dashboard showing:
  - Intern name
  - Referral code
  - Donations raised
  - Rewards section (static)
- Optional: Leaderboard

## Stack
- Frontend: HTML, CSS, JS
- Backend: Node.js + Express (Mocked data)

## Author
P. Ragavi