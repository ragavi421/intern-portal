const express = require('express');
const cors = require('cors');
const app = express();
const PORT = 5000;

app.use(cors());

const userData = {
  name: "Ragavi P",
  referralCode: "ragavi2025",
  donationsRaised: 7500
};

app.get('/api/user', (req, res) => {
  res.json(userData);
});

app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});